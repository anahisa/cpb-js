const Discord = require("discord.js");

module.exports.run = async (bot, message, args) => {
    let kUser = message.guild.member(message.mentions.users.first() || message.guild.members.get(args[0]));
    if(!kUser) return message.channel.send("I couldn't find that user.");
    let kReason = args.join(" ").slice(21);
    if(!message.member.hasPermission("KICK_MEMBERS")) return message.channel.send("You don't have permission to use this command.");
    if(kUser.hasPermission("KICK_MEMBERS")) return message.channel.send("You cannot kick this person.");

    let kickEmbed = new Discord.RichEmbed()
    .setDescription("User Kicked.")
    .setColor("#000000")
    .addField("Kicked User:", `${kUser} (${kUser.id})`)
    .addField("Kicked By:", `<@${message.author.id}> (${message.author.id})`)
    .addField("Time Kicked:", message.createdAt)
    .addField("Reason:", kReason);

    let kickChannel = message.guild.channels.find(`name`, "42-mod-log");
    if(!kickChannel) return message.channel.send("I couldn't find a logs channel.");

    message.guild.member(kUser).kick(kReason);
    kickChannel.send(kickEmbed);
}

module.exports.help = {
  name:"kick"
}
