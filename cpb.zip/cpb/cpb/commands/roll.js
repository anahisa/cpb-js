const Discord = require("discord.js");

module.exports.run = async (bot, message, args) => {
    var result = Math.floor((Math.random() * 20) + 1);
    message.channel.send("You rolled a: " + result);
}


module.exports.help = {
    name:"roll"
  }