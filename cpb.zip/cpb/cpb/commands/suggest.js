const Discord = require("discord.js");

module.exports.run = async (bot, message, args) => {
    let suggestion = args.join(" ");

    let suggestEmbed = new Discord.RichEmbed()
    .setDescription("New Suggestion:")
    .setColor("#000000")
    .addField("Suggested by:", `${message.author}`)
    .addField("Suggestion:", `${suggestion}`);

    let reportschannel = message.guild.channels.find(`name`, "server-suggestions-storage");

	message.channel.send(":white_check_mark: *Suggestion sent!*");
    reportschannel.send(suggestEmbed);

		
}
 
module.exports.help = {
  name: "suggest"
}