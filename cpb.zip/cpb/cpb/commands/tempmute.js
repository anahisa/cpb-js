const Discord = require("discord.js");
const ms = require("ms");

module.exports.run = async (bot, message, args) => {

  //.tempmute @user 1s/m/h/d

  let tomute = message.guild.member(message.mentions.users.first() || message.guild.members.get(args[0]));
  if(!tomute) return message.reply("Couldn't find user.");
  if(tomute.hasPermission("MANAGE_MESSAGES")) return message.channel.send(":negative_squared_cross_mark: You can't mute this user.");
  if(!message.member.hasPermission("MANAGE_MESSAGES")) return message.channel.send("You don't have permission to use this command.");
  let muterole = message.guild.roles.find(`name`, "muted");
 
  let mutetime = args[1];
  if(!mutetime) return message.reply("You didn't to specify a time. Proper usage is `.tempmute @user 1s/m/h/d`");
if(!muterole){
    try{
      muterole = await message.guild.createRole({
        name: "muted",
        color: "#000000",
        permissions:[]
        });
    }catch(e){
      console.log(e.stack);

      return;
    }
}

  await(tomute.addRole(muterole.id));
  message.channel.send(`:white_check_mark: *<@${tomute.id}> was muted!*`);

  setTimeout(function(){
    tomute.removeRole(muterole.id);
  }, ms(mutetime));


//end of module
}

module.exports.help = {
  name: "tempmute"
}
