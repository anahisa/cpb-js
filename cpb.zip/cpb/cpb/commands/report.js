const Discord = require("discord.js");

module.exports.run = async (bot, message, args) => {
    let rUser = message.guild.member(message.mentions.users.first() || message.guild.members.get(args[0]));
    if(!rUser) return message.channel.send("I couldn't find that user.");
    let rreason = args.join(" ").slice(21);

    let reportEmbed = new Discord.RichEmbed()
    .setDescription("Reports")
    .setColor("#000000")
    .addField("Reported User", `${rUser} (${rUser.id})`)
    .addField("Reported By", `${message.author} (${message.author.id})`)
    .addField("Channel:", message.channel)
    .addField("Time:", message.createdAt)
    .addField("Reason:", rreason);

    let reportschannel = message.guild.channels.find(`name`, "reports");
    if(!reportschannel) return message.channel.send("I couldn't find a reports channel.");


	message.channel.send(":white_check_mark: *User reported!*");
    reportschannel.send(reportEmbed);

}
 
module.exports.help = {
  name: "report"
}
