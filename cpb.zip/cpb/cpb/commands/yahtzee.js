const Discord = require("discord.js");

module.exports.run = async (bot, message, args) => {
    var result = Math.floor((Math.random() * 5) + 1);
    message.channel.send(`You rolled a: ${result}, ${result}, ${result}, ${result}, ${result}. (i cant be fucked making it calculate each time so have a free yahtzee :tada:`);
}


module.exports.help = {
    name:"yahtzee"
  }